# CareLink MVP — Family Care Dashboard

A browser-based prototype for the CareLink family-care coordination startup concept.

## Run it
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. No installation or internet connection is required.

## Current MVP features
- Responsive family dashboard
- Care recipient overview
- Medication/task status interactions
- Schedule screen
- Family members screen
- Activity timeline
- Emergency alert demo
- Add medicine / appointment / family member demo modals
- Responsive desktop/tablet/mobile layout

## Important
This is a frontend prototype. It does NOT send real emergency alerts, store personal health information, authenticate real users, or provide medical advice.

## Recommended next development phase
1. React/Next.js frontend
2. Node.js/Express API
3. MySQL/PostgreSQL database
4. Secure authentication and role-based access
5. Firebase push notifications
6. Real family invitations and permissions
7. Audit/activity logging
8. AI-assisted missed-check-in pattern detection with human review
9. Security/privacy review before handling real health information
10. Cloud deployment
